# StreamBox TV — Готовое приложение и сборка APK (3 способа запуска)

В этом архиве собраны все файлы для запуска онлайн-ТВ на Android и Android TV, включая автоматическую облачную сборку `.apk` без установки Android Studio.

---

## Способ 1. Запуск на смартфоне Android прямо сейчас (без сборки APK)

1. Передайте файл **`StreamBox_TV_Mobile_WebApp.html`** из этого архива на свой Android-смартфон или планшет (например, через Telegram, Google Диск или кабель).
2. Откройте его в браузере **Google Chrome**.
3. Нажмите меню Chrome (**⋮** в правом верхнем углу) → **«Добавить на главный экран»** (или «Установить приложение»).
4. На рабочем столе телефона появится иконка **StreamBox TV** — приложение будет открываться на весь экран как обычная программа.

---

## Способ 2. Автоматическая сборка `.APK` в облаке (без установки Android Studio на ПК)

В архив уже встроен сценарий автоматической облачной сборки **GitHub Actions** (`.github/workflows/build-apk.yml`):

1. Создайте бесплатный репозиторий на [github.com](https://github.com/new) и загрузите туда содержимое папки `android-native-compose` (вместе с папкой `.github`).
2. Перейдите на вкладку **Actions** в вашем репозитории и нажмите **Build Android APK → Run workflow**.
3. Через 2–3 минуты облачный сервер Google/GitHub сам скачает Android SDK, скомпилирует проект и выдаст готовый файл **`StreamBoxTV-debug.apk`** в разделе **Artifacts** — скачайте его и установите на телефон или ТВ-приставку.

---

## Способ 3. Локальная сборка `.APK` на компьютере

- **Через скрипт в 1 клик:** запустите `build_apk_windows.bat` (на Windows) или `build_apk_linux_mac.sh` (на macOS/Linux) внутри папки `android-native-compose` (при установленном Android SDK).
- **Через Android Studio:** откройте папку `android-native-compose` в Android Studio и выберите в меню **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Готовый файл появится по пути `app/build/outputs/apk/debug/app-debug.apk`.
