import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

void main() => runApp(const StreamBoxFlutterApp());

class StreamBoxFlutterApp extends StatelessWidget {
  const StreamBoxFlutterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'StreamBox TV Online',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true),
      home: const TvHomeScreen(),
    );
  }
}

class TvHomeScreen extends StatefulWidget {
  const TvHomeScreen({super.key});
  @override
  State<TvHomeScreen> createState() => _TvHomeScreenState();
}

class _TvHomeScreenState extends State<TvHomeScreen> {
  VideoPlayerController? _controller;
  int _selectedIndex = 0;

  final List<Map<String, String>> channels = [
    {
      'name': 'Первый Информационный 24',
      'group': 'Новости',
      'url': 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
      'epg': '14:00 - 15:00 • Главные новости часа'
    },
    {
      'name': 'Cinema Ultra HD',
      'group': 'Кино',
      'url': 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
      'epg': '13:30 - 15:30 • Хроники стратосферы'
    },
    {
      'name': 'Спорт Арена Live',
      'group': 'Спорт',
      'url': 'https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8',
      'epg': '13:45 - 15:45 • Лига Чемпионов'
    }
  ];

  @override
  void initState() {
    super.initState();
    _loadChannel(0);
  }

  Future<void> _loadChannel(int index) async {
    setState(() => _selectedIndex = index);
    await _controller?.dispose();
    final ctrl = VideoPlayerController.networkUrl(Uri.parse(channels[index]['url']!));
    _controller = ctrl;
    await ctrl.initialize();
    if (mounted) {
      setState(() {});
      ctrl.play();
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ctrl = _controller;
    return Scaffold(
      appBar: AppBar(title: const Text('StreamBox TV Online')),
      body: Column(
        children: [
          AspectRatio(
            aspectRatio: 16 / 9,
            child: (ctrl != null && ctrl.value.isInitialized)
                ? VideoPlayer(ctrl)
                : const ColoredBox(
                    color: Colors.black,
                    child: Center(child: CircularProgressIndicator()),
                  ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: channels.length,
              itemBuilder: (context, idx) {
                final ch = channels[idx];
                return ListTile(
                  selected: idx == _selectedIndex,
                  leading: CircleAvatar(child: Text('${idx + 1}')),
                  title: Text(ch['name']!),
                  subtitle: Text('${ch['group']} • ${ch['epg']}'),
                  onTap: () => _loadChannel(idx),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
